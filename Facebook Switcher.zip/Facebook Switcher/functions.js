var msg,msg2;
var kisaformat;
var aralik;
window.addEventListener( 'load', function() {
	aralik = (localStorage["aralik"])*1000;
	if(localStorage["aralik"]==null) { aralik=5000; localStorage["aralik"]=5;};
	document.getElementById('baslik').innerHTML=chrome.i18n.getMessage("baslik");
}, false );

function mesaj(){
	document.getElementById('sure').innerHTML=time(localStorage["sure"],bos1);
	document.getElementById('toplamsure').innerHTML="<b>"+chrome.i18n.getMessage("internetsuresi")+": </b>"+time(localStorage["toplamsure"],bos2);
}

function isSwitchPage(){
	if(isTimesUp(localStorage["sure"])){
		chrome.extension.sendRequest({redirect: "http://wikipedia.com"});
		clearInterval(itvlSwitchId);
		//switch page!
	}
}
//aralik: time interval
setInterval(mesaj, aralik);
//var itvlSwitchId = setInterval(isSwitchPage, aralik);

//-----------------------------------------
function tarihfarki(t1,t2){
	var t1 = new Date(t1);
	var t2 = new Date(t2);
	var sonuc=t1-t2;
	sonuc=sonuc/1000/60/60/24;
	return sonuc;
}

var gun=chrome.i18n.getMessage("gun"),saat=chrome.i18n.getMessage("saat"),dakika=chrome.i18n.getMessage("dakika"),saniye=chrome.i18n.getMessage("saniye");
var cogul=chrome.i18n.getMessage("coguleki");
var bos1=chrome.i18n.getMessage("henuzgirmediniz"),bos2=chrome.i18n.getMessage("henuzgezmediniz");
kisaformat = localStorage["kisaformat"];
if(kisaformat=="evet") { gun=chrome.i18n.getMessage("gunkisa"),saat=chrome.i18n.getMessage("saatkisa"),dakika=chrome.i18n.getMessage("dakikakisa"),saniye=chrome.i18n.getMessage("saniyekisa"),cogul=""; }

function isTimesUp(sec){
	//if(sec/60 >= 1) alert(sec/60 >= 1);
	return (sec/60 >= 1);
}

function time(sec,bos) {
	var t = "";
	if(sec==0 || sec==null || sec=="") t=bos;
	var min = Math.floor(sec/60)
	
	sec = sec % 60
	if(sec>0){
		t = sec+" "+saniye+cogul;
	}
	var hr = Math.floor(min/60)
	
	min = min % 60
	if(min>0)
	{
		if(min==1) t = min + " "+dakika+" " + t
			else t = min + " "+dakika+cogul+" " + t
		}
	var day = Math.floor(hr/24)
	
	hr = hr % 24
	if(hr>0)
	{
		if(hr==0) t = hr + " "+saat+" " + t
			else t = hr + " "+saat+cogul+" " + t
		}
	if(day>0)
	{
		if(day==0) t = day + " "+gun+" " + t
			else t = day + " "+gun+cogul+" " + t
		}
	return t;
}
function ellesifirla(id,str)
{
	chrome.extension.sendRequest({islem:"sifirla"}, function(response) {
  			//console.log(response.farewell);
  		});
	var durum = document.getElementById(id);
	durum.innerHTML = str;
	durum.style.display="block";
	setTimeout(function() {
		durum.style.display="none";
	}, 2000);
}
document.addEventListener("DOMContentLoaded", function(event){
		// document.onmousemove = function(){
		// 	alert("mouse moved~");
		// 	clearTimeout(timeout);
		// 	timeout = setTimeout(redirectPage, 60000);
		// };
	mesaj();
});