	console.log(document.getElementById("mainContainer"));
	document.getElementById("mainContainer").onmousemove = function(){
			console.log("mouse moved~");
			chrome.storage.local.set({"time" : 0});
	};
