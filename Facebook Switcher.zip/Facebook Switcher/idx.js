var fb = "facebook.com";
var youtube = "youtube.com";

window.addEventListener("load", function(){
	chrome.storage.local.set({"time" : 1});
	var time = 0;
	chrome.storage.local.get("time", function(result){
		time = result.time;
	});
	console.log(time);
	timer=setInterval(check, 5000);
}, false);

function testRequest(){
	alert("test success");
}

function check(){
	chrome.tabs.getSelected(null, function(tab){
		var url = tab.url;
		if(null != url){
			address = url;
			if(address.indexOf("http") != -1){
				if((address.indexOf(fb) != -1) || (address.indexOf(youtube) != -1)){
					console.log("facebook");
					var time = 0;
					chrome.storage.local.get("time", function(result){
						console.log(result.time);
						time = result.time;
						if(time >= 30){
							console.log("time >= 30");
							chrome.tabs.getCurrent(function (tab) {
								console.log(tab);
								chrome.tabs.update(null, {url: "http://wmnlab.ee.ntu.edu.tw/nmlab/index.html"});
								console.log("redirect done");
							});
							chrome.storage.local.set({"time" : 0});
							var t = 0;
							chrome.storage.local.get("get", function(result){
								t = result.time;
								console.log(t);
							});
							return;
						}
						else{
							chrome.storage.local.set({"time" : (time + 5)});
							var tme = 0;
							chrome.storage.local.get("time", function(result){
								tme = result.time;
								console.log(tme);
							});
						}
						chrome.tabs.executeScript(null, {file: "myscript.js"});
					});
				}
			}
		}
	})
}

